const requireDir = require('require-dir');

module.exports = requireDir('./');
