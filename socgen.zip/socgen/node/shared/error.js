const ErrorResponse = (type, description, code) => ({ type, description, code });

module.exports = ErrorResponse;