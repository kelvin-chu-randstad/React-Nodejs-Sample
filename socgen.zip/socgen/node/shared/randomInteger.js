const RandomInteger = (max, min) => Math.floor(Math.random() * (max - min) + min);

module.exports = RandomInteger;