export const GET_STOCKS = '@@stocks/GET_STOCKS';
export const GET_STOCKS_SUCCESS = '@@stocks/GET_STOCKS_SUCCESS';
export const GET_STOCKS_ERROR = '@@stocks/GET_STOCKS_ERROR';
export const SEARCH_STOCKS = '@@stocks/SEARCH_STOCKS';
