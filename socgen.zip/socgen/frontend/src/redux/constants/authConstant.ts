export const LOG_IN = '@@stocks/LOG_IN';
export const SIGN_UP = '@@stocks/SIGN_UP';
export const AUTH_SUCCESS = '@@stocks/AUTH_SUCCESS';
export const AUTH_ERROR = '@@stocks/AUTH_ERROR';
export const LOG_OUT = '@@stocks/LOG_OUT';
export const SESSION_TIME_OUT = '@@stocks/SESSION_TIME_OUT';
