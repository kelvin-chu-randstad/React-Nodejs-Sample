import styled from 'styled-components';
import { Alert as A } from 'react-bootstrap';

export const Alert = styled(A)`
  width: 100%;
  margin: 0;
`;
