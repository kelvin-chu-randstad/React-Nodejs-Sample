import styled from 'styled-components';

export const TableErrorContainer = styled.td`
  border-top: none !important;
  padding-top: 0 !important;
`;
