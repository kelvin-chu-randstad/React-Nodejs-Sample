import styled from 'styled-components';

export const TableCell = styled.td`
  vertical-align: middle !important;
  text-align: center;
`;
