import styled from 'styled-components';

export const TableHead = styled.th`
  text-align: center;
`;
