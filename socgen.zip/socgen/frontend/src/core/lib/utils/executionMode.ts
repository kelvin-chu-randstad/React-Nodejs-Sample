import { OrderExecutionMode } from '../../../types/types';

export const ExecutionMode: OrderExecutionMode[] = ['Market', 'Limit'];
