import { AuthMode } from '../../../types/types';

export const AuthType: AuthMode[] = ['Sign Up', 'Log In'];
