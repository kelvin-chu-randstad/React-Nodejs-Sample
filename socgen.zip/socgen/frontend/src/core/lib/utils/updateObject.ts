export const updateObject = (oldObj: any, updatedProps: any) => ({
  ...oldObj,
  ...updatedProps,
});
