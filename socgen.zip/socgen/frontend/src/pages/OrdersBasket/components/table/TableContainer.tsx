import styled from 'styled-components';
import { Table } from 'react-bootstrap';

export const TableContainer = styled(Table)`
  padding-bottom: 100px;
`;
