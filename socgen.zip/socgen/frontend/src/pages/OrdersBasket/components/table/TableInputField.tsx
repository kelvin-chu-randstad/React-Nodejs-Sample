import styled from 'styled-components';
import { FormControl } from 'react-bootstrap';

export const TableInputField = styled(FormControl)`
  width: 100%;
`;
